package com.fongmi.android.tv.content;

import android.app.Activity;
import android.text.TextUtils;

import com.fongmi.android.tv.App;
import com.fongmi.android.tv.api.SiteApi;
import com.fongmi.android.tv.bean.ComicSourceConfig;
import com.fongmi.android.tv.bean.Episode;
import com.fongmi.android.tv.bean.Flag;
import com.fongmi.android.tv.bean.NovelSourceConfig;
import com.fongmi.android.tv.bean.Result;
import com.fongmi.android.tv.bean.Vod;
import com.fongmi.android.tv.ui.novel.NovelRouter;
import com.fongmi.android.tv.utils.ActivityLaunch;
import com.fongmi.android.tv.utils.Notify;
import com.fongmi.android.tv.utils.Sniffer;
import com.fongmi.android.tv.utils.Task;

import java.util.List;

public class ReaderContentHandler implements ContentHandler {

    @Override
    public boolean canHandleSite(String key, String name) {
        return NovelSourceConfig.isSiteEnabled(key, name) || ComicSourceConfig.isSiteEnabled(key, name);
    }

    @Override
    public boolean canHandleUrl(String url) {
        return readerKind(url) != 0;
    }

    @Override
    public boolean handleSite(Activity activity, String key, String id, String name, String pic, String mark) {
        int preferredKind = ComicSourceConfig.isSiteEnabled(key, name) ? 2 : 1;
        if (!canHandleSite(key, name)) return false;
        Notify.show(preferredKind == 2 ? "正在加载漫画" : "正在加载小说");
        Task.execute(() -> {
            try {
                Result detail = SiteApi.detailContent(key, id);
                Vod vod = detail.getVod();
                vod.checkName(name);
                vod.checkPic(pic);
                Flag flag = selectFlag(vod, mark);
                if (flag == null || flag.getEpisodes().isEmpty()) throw new IllegalStateException("暂无可阅读章节");
                Episode episode = selectEpisode(flag, mark);
                int index = Math.max(0, flag.getEpisodes().indexOf(episode));
                Result result = SiteApi.playerContent(key, flag.getFlag(), episode.getUrl());
                String payload = NovelRouter.content(result);
                if (TextUtils.isEmpty(payload)) throw new IllegalStateException("正文解析结果为空");
                int detectedKind = NovelRouter.readerUrlKind(result);
                int kind = detectedKind == 0 ? preferredKind : detectedKind;
                App.post(() -> ActivityLaunch.postOnAnimation(activity, () -> NovelRouter.openResolved(
                        activity, kind, payload, key, flag.getFlag(), id, vod.getName(), vod.getPic(),
                        flag.getEpisodes(), index)));
            } catch (Throwable e) {
                App.post(() -> Notify.show(TextUtils.isEmpty(e.getMessage()) ? "阅读内容加载失败" : e.getMessage()));
            }
        });
        return true;
    }

    @Override
    public boolean handleUrl(Activity activity, String url, String title) {
        int kind = readerKind(url);
        if (kind == 0) return false;
        NovelRouter.openResolved(activity, kind, url, "", "", "", title, "", null, 0);
        return true;
    }

    @Override
    public boolean handleResult(Activity activity, String historyKey, String siteKey, String flag,
                                String vodName, String vodPic, List<Episode> episodes, int position,
                                Result result, long timeout) {
        String payload = NovelRouter.content(result);
        int kind = NovelRouter.readerUrlKind(result);
        if (kind == 0 && NovelSourceConfig.isEnabledByKey(siteKey) && isReadable(payload)) kind = 1;
        if (kind == 0 && ComicSourceConfig.isEnabledByKey(siteKey) && isReadable(payload)) kind = 2;
        if (kind == 0) return false;
        NovelRouter.openResolved(activity, kind, payload, siteKey, flag, "", vodName, vodPic,
                episodes, position);
        return true;
    }

    private static Flag selectFlag(Vod vod, String mark) {
        if (vod == null || vod.getFlags() == null || vod.getFlags().isEmpty()) return null;
        if (!TextUtils.isEmpty(mark)) {
            for (Flag flag : vod.getFlags()) if (mark.equals(flag.getFlag())) return flag;
        }
        return vod.getFlags().get(0);
    }

    private static Episode selectEpisode(Flag flag, String mark) {
        if (!TextUtils.isEmpty(mark)) {
            Episode episode = flag.find(mark, false);
            if (episode != null) return episode;
        }
        return flag.getEpisodes().get(0);
    }

    private static int readerKind(String value) {
        if (value == null) return 0;
        String url = value.trim();
        if (url.startsWith("novel://")) return 1;
        if (url.startsWith("pics://") || url.startsWith("manga://")) return 2;
        return 0;
    }

    private static boolean isReadable(String payload) {
        return !TextUtils.isEmpty(payload) && (readerKind(payload) != 0 || !Sniffer.isVideoFormat(payload));
    }
}
