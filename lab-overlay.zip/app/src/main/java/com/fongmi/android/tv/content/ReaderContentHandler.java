package com.fongmi.android.tv.content;

import android.app.Activity;

import com.fongmi.android.tv.bean.Episode;
import com.fongmi.android.tv.bean.Result;
import com.fongmi.android.tv.ui.novel.NovelRouter;

import java.util.List;

public class ReaderContentHandler implements ContentHandler {

    @Override
    public boolean canHandleSite(String key, String name) {
        // `name` at this entry point is the VOD title, not the source name.
        // Resolve the real source by key so a movie title cannot accidentally
        // match a novel/comic source rule.
        return NovelRouter.configuredReaderKind(key) != 0;
    }

    @Override
    public boolean canHandleUrl(String url) {
        return readerKind(url) != 0;
    }

    @Override
    public boolean handleSite(Activity activity, String key, String id, String name, String pic, String mark) {
        if (!canHandleSite(key, name)) return false;
        int kind = NovelRouter.configuredReaderKind(key);
        NovelRouter.openPendingSite(activity, kind, key, id, name, pic, mark);
        return true;
    }

    @Override
    public boolean handleUrl(Activity activity, String url, String title) {
        int kind = readerKind(url);
        if (kind == 0) return false;
        NovelRouter.openResolved(activity, kind, url, "", "", "", title, "", null, 0);
        return true;
    }

    @Override
    public boolean handleResult(Activity activity, String historyKey, String siteKey, String flag,
                                String vodName, String vodPic, List<Episode> episodes, int position,
                                Result result, long timeout) {
        // 只能由源配置决定类型，解析结果的协议、URL 形状和媒体格式都不能
        // 把未配置的视频源变成小说或漫画。
        int kind = NovelRouter.configuredReaderKind(siteKey);
        if (kind == 0) return false;
        String payload = NovelRouter.content(result);
        NovelRouter.openResolved(activity, kind, payload, siteKey, flag, "", vodName, vodPic,
                episodes, position);
        return true;
    }

    private static int readerKind(String value) {
        if (value == null) return 0;
        String url = value.trim();
        if (url.startsWith("novel://")) return 1;
        if (url.startsWith("pics://") || url.startsWith("manga://")) return 2;
        return 0;
    }

}
