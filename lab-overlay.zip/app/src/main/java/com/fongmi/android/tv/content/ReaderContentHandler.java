package com.fongmi.android.tv.content;

import android.app.Activity;

import com.fongmi.android.tv.bean.ComicSourceConfig;
import com.fongmi.android.tv.bean.Episode;
import com.fongmi.android.tv.bean.NovelSourceConfig;
import com.fongmi.android.tv.bean.Result;
import com.fongmi.android.tv.ui.novel.NovelRouter;

import java.util.List;

public class ReaderContentHandler implements ContentHandler {

    @Override
    public boolean canHandleSite(String key, String name) {
        // `name` at this entry point is the VOD title, not the source name.
        // Resolve the real source by key so a movie title cannot accidentally
        // match a novel/comic source rule.
        return NovelSourceConfig.isEnabledByKey(key)
                || ComicSourceConfig.isEnabledByKey(key);
    }

    @Override
    public boolean canHandleUrl(String url) {
        return readerKind(url) != 0;
    }

    @Override
    public boolean handleSite(Activity activity, String key, String id, String name, String pic, String mark) {
        if (!canHandleSite(key, name)) return false;
        int kind = ComicSourceConfig.isEnabledByKey(key) ? 2 : 1;
        NovelRouter.openPendingSite(activity, kind, key, id, name, pic, mark);
        return true;
    }

    @Override
    public boolean handleUrl(Activity activity, String url, String title) {
        int kind = readerKind(url);
        if (kind == 0) return false;
        NovelRouter.openResolved(activity, kind, url, "", "", "", title, "", null, 0);
        return true;
    }

    @Override
    public boolean handleResult(Activity activity, String historyKey, String siteKey, String flag,
                                String vodName, String vodPic, List<Episode> episodes, int position,
                                Result result, long timeout) {
        String payload = NovelRouter.content(result);
        int kind = NovelRouter.readerUrlKind(result);
        if (kind == 0 && ComicSourceConfig.isEnabledByKey(siteKey)) kind = 2;
        if (kind == 0 && NovelSourceConfig.isEnabledByKey(siteKey)) kind = 1;
        // Unconfigured sites are never guessed from URL shape. An http(s)
        // value may be an iframe, parser endpoint or signed video URL; those
        // must continue through the normal video player.
        if (kind == 0) return false;
        NovelRouter.openResolved(activity, kind, payload, siteKey, flag, "", vodName, vodPic,
                episodes, position);
        return true;
    }

    private static int readerKind(String value) {
        if (value == null) return 0;
        String url = value.trim();
        if (url.startsWith("novel://")) return 1;
        if (url.startsWith("pics://") || url.startsWith("manga://")) return 2;
        return 0;
    }

}
