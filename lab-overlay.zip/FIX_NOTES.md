lab-overlay v3
Fix missing string lab_empty_no_source for view_lab_empty.xml
Keep upstream compatible overlay.
