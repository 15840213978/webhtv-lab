package com.fongmi.android.tv.lab;

import com.fongmi.android.tv.App;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class LabProcManager {

    private static final Gson GSON = new Gson();
    private static final Map<String, Integer> RECOVERED = new ConcurrentHashMap<>();
    private static final Map<String, File> LOGS = new ConcurrentHashMap<>();
    private static volatile boolean recovered;

    private LabProcManager() {
    }

    public static File pidsDir() {
        File dir = new File(LabConfig.get().getRoot(), "pids");
        dir.mkdirs();
        return dir;
    }

    public static File logsDir() {
        File dir = new File(LabConfig.get().getRoot(), "logs");
        dir.mkdirs();
        return dir;
    }

    public static File logFile(int pid, String pkg) {
        return new File(logsDir(), (pid > 0 ? pid : 0) + "_" + pkg + ".log");
    }

    private static File stateFile() {
        return new File(App.get().getFilesDir(), "lab_process_state.json");
    }

    private static File pidFile(String key) {
        return new File(pidsDir(), key.replace('/', '_') + ".pid");
    }

    public static synchronized void recover() {
        if (recovered) return;
        recovered = true;
        try {
            Map<String, JsonObject> state = loadState();
            List<String> dead = new ArrayList<>();
            for (Map.Entry<String, JsonObject> entry : state.entrySet()) {
                try {
                    int pid = entry.getValue().get("pid").getAsInt();
                    if (pid > 0 && new File("/proc/" + pid).exists()) {
                        RECOVERED.put(entry.getKey(), pid);
                    } else {
                        dead.add(entry.getKey());
                    }
                } catch (Exception e) {
                    dead.add(entry.getKey());
                }
            }
            for (String key : dead) state.remove(key);
            saveState(state);
        } catch (Exception ignored) {
        }
    }

    public static synchronized void track(String key, int pid, String pkg, String cmd) {
        try {
            File log = logFile(pid, pkg);
            File pf = pidFile(key);
            pf.getParentFile().mkdirs();
            try (FileWriter writer = new FileWriter(pf)) {
                writer.write(String.valueOf(pid));
            }
            JsonObject entry = new JsonObject();
            entry.addProperty("pid", pid);
            entry.addProperty("pkg", pkg);
            entry.addProperty("cmd", cmd);
            entry.addProperty("log", log.getAbsolutePath());
            Map<String, JsonObject> state = loadState();
            state.put(key, entry);
            saveState(state);
            RECOVERED.remove(key);
            LOGS.put(key, log);
        } catch (Exception ignored) {
        }
    }

    public static synchronized void untrack(String key) {
        try {
            pidFile(key).delete();
        } catch (Exception ignored) {
        }
        Map<String, JsonObject> state = loadState();
        state.remove(key);
        saveState(state);
        RECOVERED.remove(key);
        LOGS.remove(key);
    }

    public static File logFor(String key) {
        return LOGS.get(key);
    }

    public static boolean recoveredAlive(String key) {
        Integer pid = RECOVERED.get(key);
        return pid != null && pid > 0 && new File("/proc/" + pid).exists();
    }

    public static int recoveredCount() {
        return RECOVERED.size();
    }

    public static synchronized void stop(String key) {
        Integer pid = RECOVERED.remove(key);
        if (pid != null && pid > 0) killPid(pid);
        untrack(key);
    }

    public static synchronized void stopAll() {
        for (String key : new ArrayList<>(RECOVERED.keySet())) stop(key);
    }

    private static void killPid(int pid) {
        try {
            Runtime.getRuntime().exec(new String[]{"kill", String.valueOf(pid)}).waitFor();
        } catch (Exception ignored) {
        }
        try {
            Runtime.getRuntime().exec(new String[]{"kill", "-9", String.valueOf(pid)}).waitFor();
        } catch (Exception ignored) {
        }
        try {
            Runtime.getRuntime().exec(new String[]{"kill", "-9", "-" + String.valueOf(pid)}).waitFor();
        } catch (Exception ignored) {
        }
    }

    private static Map<String, JsonObject> loadState() {
        try {
            File file = stateFile();
            if (!file.exists()) return new LinkedHashMap<>();
            Map<String, JsonObject> map = GSON.fromJson(new FileReader(file), new TypeToken<Map<String, JsonObject>>() {
            }.getType());
            return map == null ? new LinkedHashMap<>() : map;
        } catch (Exception e) {
            return new LinkedHashMap<>();
        }
    }

    private static void saveState(Map<String, JsonObject> state) {
        try (FileWriter writer = new FileWriter(stateFile())) {
            GSON.toJson(state, writer);
        } catch (Exception ignored) {
        }
    }

    public static void updateService() {
        LabRuntimeService.update();
    }
}
