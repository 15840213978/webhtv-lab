lab-overlay build test

Removed full Java overlays that conflicted with upstream API changes:
- VideoActivity.java
- TmdbDetailActivity.java
- NovelRouter.java
- NovelReaderHost.java

Goal: let upstream Silent1566/webhtv compile first.
